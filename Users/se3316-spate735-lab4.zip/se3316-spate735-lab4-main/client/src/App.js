import React from "react";
import "./App.css";
import { Routes, Route } from "react-router-dom"; 
import UserHomePage from "./UserHomePage";
import HomePage from "./HomePage";
import AdminHomePage from "./AdminHomePage";
import UserContext from './UserContext';
import { useState } from 'react';

function App() {
  // Initialize user state using the useState hook
  const [user, setUser] = useState(null);

  return (
    // Wrap Routes with UserContext.Provider to provide user information to child components
    <UserContext.Provider value={{ user, setUser }}>
      <Routes>
        {/* Route for the home page */}
        <Route path="/" element={<HomePage />} />

        {/* Route for the user home page */}
        <Route path="/user-home-page" element={<UserHomePage />} />

        {/* Route for the admin home page */}
        <Route path="/admin-home-page" element={<AdminHomePage />} />
      </Routes>
    </UserContext.Provider>
  );
}

export default App;