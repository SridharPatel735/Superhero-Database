import React from "react";
import "./UserHomePage.css";
import UserContext from './UserContext';
import sanitizeHtml from 'sanitize-html';
import { useState } from 'react';
import { NavLink } from "react-router-dom";

// UserHomePage component
function UserHomePage() {
    const { user } = React.useContext(UserContext);
    const [listCounter, setListCounter] = useState(0);
    React.useEffect(() => {
        listTables();
    }, []); 
    //Adding all tables to the dropdown
    function listTables(){
        fetch(`/api/superheroes/tableNames`)
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json(); // Parse the response as JSON
        })
        .then((responseData) => {
            // Handle the response data
            let dropDown = document.getElementById("listOption");

            let i; 
            let length = dropDown.options.length - 1;
            for(i = length; i >= 0; i--) {
                dropDown.remove(i);
            }
            console.log("data:", responseData)

            //Adding all tables to the dropdown
            for (let index of responseData) {
                if ((!(index == "superpowers" || index == "superheroinfos" || index == "users")) && (index.includes(user))){
                    let temp = listCounter;
                    temp++;
                    setListCounter(temp);
                    let option = document.createElement("option");
                    let listName = index.split(user)[0];
                    option.textContent = listName;
                    option.value = listName;
                    dropDown.appendChild(option);
                }
            }
        })
        .catch((error) => {
            alert(error);
        });
    }

    //Creating a new list
    function createList(){
        //Sanitizing the input
        const input = document.getElementById("listNameInput").value;
        const publicInput = document.getElementById("publicOption").value;
        let listName = sanitizeHtml(input + user + publicInput);
        fetch(`/api/superheroes/${listName}`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
        })
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json(); // Parse the response as JSON
        })
        .then((responseData) => {
            // Handle the response data
            console.log("data:", responseData)
            let temp = listCounter;
            temp++;
            setListCounter(temp);
            //Disabling the button if the user has 20 lists
            if (listCounter >= 20){
                const btn = document.getElementById("addList");
                btn.disabled = true;
            }
            else if (listCounter < 20){
                const btn = document.getElementById("addList");
                btn.disabled = false;
            }
            alert("User updated successfully!")
        })
        .catch((error) => {
            alert(error);
        });
        listTables();
    }

    //Finding a list
    function findList(){
        const input = document.getElementById("listOption").value;

        fetch(`/api/superheroes/tableNames`)
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json(); // Parse the response as JSON
        })
        .then((responseData) => {
            // Handle the response data
            for (let index of responseData) {
                if ((index.includes(user)) && (index.includes(input))){
                    deleteList(index);
                }
            }
        })
        .catch((error) => {
            alert(error);
        });
    }

    //Deleting a list
    function deleteList(listName){
        fetch(`/api/superheroes/${listName}/deleteList`, {
            method: 'DELETE',
            headers: {'Content-Type': 'application/json'},
        })
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json(); // Parse the response as JSON
        })
        .then((responseData) => {
            // Handle the response data
            console.log("data:", responseData)
            let temp = listCounter;
            temp--;
            setListCounter(temp);
            if (listCounter >= 20){
                const btn = document.getElementById("addList");
                btn.disabled = true;
            }
            else if (listCounter < 20){
                const btn = document.getElementById("addList");
                btn.disabled = false;
            }
            alert("User updated successfully!")
        })
        .catch((error) => {
            alert(error);
        });
        listTables();
    }

 // Return the JSX element
  return (
    <div className="user-home-page">
        <header className="App-header">
            <select id="listOption">
            </select>
        </header>
        <div className="createList">
            <label>Create List: </label>
            <input type="text" id="listNameInput" placeholder="List name..."></input>
            <button id="addList" onClick={createList}>Create</button>
            <select id="publicOption">
                <option value="public">Public</option>
                <option value="private">Private</option>
            </select>
            <button id="deleteList" onClick={findList}>Delete</button>
            <NavLink to="/">
                <button>Go to home page</button>
            </NavLink>
        </div>
    </div>
  );
}
export default UserHomePage;