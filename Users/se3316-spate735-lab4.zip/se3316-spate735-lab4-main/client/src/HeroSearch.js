import React, { useState } from 'react';
import './HeroSearch.css';
import sanitizeHtml from 'sanitize-html';

//  HeroSearch component
const HeroSearch = () => {
  const [heroInfo, setHeroInfo] = useState([]);
  const [expandedIndex, setExpandedIndex] = useState(null);
  const [searchTerms, setSearchTerms] = useState({
    name: '',
    race: '',
    power: '',
    publisher: '',
  });
  
  // Fetch all hero info from the server
  const handleToggleExpand = (index) => {
    setExpandedIndex((prevIndex) => (prevIndex === index ? null : index));
  };

  // Sanitize the input to prevent XSS attacks
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setSearchTerms((prevSearchTerms) => ({ ...prevSearchTerms, [name]: sanitizeHtml(value) }));
  };

  const handleSearchButtonClick = (heroName, publisher) => {
    // Construct the DuckDuckGo search URL based on hero name and publisher
    const searchQuery = `${heroName} ${publisher}`;
    const searchUrl = `https://duckduckgo.com/?q=${encodeURIComponent(searchQuery)}`;

    // Open a new tab with the constructed URL
    window.open(searchUrl, '_blank');
  };

  // Fuzzy search algorithm
  const fuzzySearch = (input, target) => {
    const inputLowerCase = input.replace(/\s/g, "").toLowerCase();
    const targetLowerCase = target.replace(/\s/g, "").toLowerCase();

    // Allow up to two characters to be missing or different
    let mismatchCount = 0;
    for (let i = 0; i < inputLowerCase.length && mismatchCount <= 2; i++) {
      if (inputLowerCase[i] !== targetLowerCase[i]) {
        mismatchCount++;
      }
    }

    if (mismatchCount > 2) {
      return false;
    }
    else {
      return true;
    }
  };

  // Handle search button click
  const handleSearch = () => {
    console.log('Search Terms:', searchTerms);

    fetch(`/api/superheroes/everyHero/allInfo/search/power`)
      .then((res) => res.json())
      .then((data) => {
        const output = [];

        // Filter the data based on the search terms
        for (let hero of data){
          let nameB = false;
          let raceB = false;
          let powerB = false;
          let publisherB = false;

          // Check if the search term is empty
          if (searchTerms.name !== ""){
            if (fuzzySearch(searchTerms.name, hero.name)){
              nameB = true;
            } 
            else{
              nameB = false;
            }
          }
          else{
            nameB = true;
          }

          // Check if the search term is empty
          if (searchTerms.race !== ""){
            if (fuzzySearch(searchTerms.race, hero.Race)){
              raceB = true;
            }
            else{
              raceB = false;
            }
          }
          else{
            raceB = true;
          }

          // Check if the search term is empty
          if (searchTerms.power !== ""){
            for (let heroPower of hero.Powers){
              if (fuzzySearch(searchTerms.power, heroPower)){
                powerB = true;
                break;
              }
            }
          }
          else{
            powerB = true;
          }

          // Check if the search term is empty
          if (searchTerms.publisher !== ""){
            if (fuzzySearch(searchTerms.publisher, hero.Publisher)){
              publisherB = true;
            }
            else{
              publisherB = false;
            }
          }
          else{
            publisherB = true;
          }

          // If all search terms are true, add the hero to the output
          if (nameB === true && raceB === true && powerB === true && publisherB === true){
            output.push(hero);
          }
        }
        console.log('Output:', output);
        setHeroInfo(output);
      })
      .catch((error) => {
        console.error('Fetch Error:', error);
      });

  };

  // Render the HeroSearch component
  return (
    <div className="hero-search-container">
      <h2>Search Heroes</h2>
      <div className="search-form">
        <input
          type="text"
          name="name"
          placeholder="Hero Name"
          value={searchTerms.name}
          onChange={handleInputChange}
        />
        <input
          type="text"
          name="race"
          placeholder="Race"
          value={searchTerms.race}
          onChange={handleInputChange}
        />
        <input
          type="text"
          name="power"
          placeholder="Power"
          value={searchTerms.power}
          onChange={handleInputChange}
        />
        <input
          type="text"
          name="publisher"
          placeholder="Publisher"
          value={searchTerms.publisher}
          onChange={handleInputChange}
        />
        <button onClick={handleSearch}>Search</button>
      </div>
      <div id='search-Output'>
        <ul>
          {heroInfo.map((hero, index) => (
            <li key={index} onClick={() => handleToggleExpand(index)}>
              <div className='resultHeader'>
                Name: {hero.name} <br />
                Publisher: {hero.Publisher}
              </div>
              {expandedIndex === index && (
                <div className='expandedInfo'>
                  ID: {hero.id} <br />
                  Gender: {hero.Gender} <br />
                  Eye Color: {hero['Eye color']} <br />
                  Race: {hero.Race} <br />
                  Hair Color: {hero['Hair color']} <br />
                  Height: {hero.Height} <br />
                  Publisher: {hero.Publisher} <br />
                  Skin Color: {hero['Skin color']} <br />
                  Alignment: {hero.Alignment} <br />
                  Weight: {hero.Weight} <br />
                  Powers: 
                  <ul>
                    {hero.Powers.map((power, index) => (
                      <li key={index}>{power}</li>
                    ))}
                  </ul>
                  <button
                    onClick={() => handleSearchButtonClick(hero.name, hero.Publisher)}>
                    Search
                  </button>
                </div>
              )}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

// Export the HeroSearch component
export default HeroSearch;