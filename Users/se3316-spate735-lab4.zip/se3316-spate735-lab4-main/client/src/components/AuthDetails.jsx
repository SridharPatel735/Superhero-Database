import { onAuthStateChanged, signOut } from 'firebase/auth';
import React, { useEffect, useState } from 'react';
import { auth } from '../firebase';
import { NavLink } from 'react-router-dom';

const AuthDetails = () => {
    const [authUser, setAuthUser] = useState(null);

    useEffect(() => {
        const listen = onAuthStateChanged(auth, (user) => {
            if (user) {
                // Check if the user is verified before setting the user
                if (user.emailVerified) {
                    setAuthUser(user);
                } else {
                    setAuthUser(null);
                }
            } else {
                setAuthUser(null);
            }
        });
        return () => {
            listen();
        }
    }, []);

    const userSignOut = () => {
        signOut(auth).then(() => {
            console.log('Signed Out');
        }).catch((error) => {
            console.log(error);
        });
    }

    return (
        <div>
            {authUser ? (
                authUser.emailVerified ? (
                    <>
                        {/* <NavLink to="/">
                            <button onClick={userSignOut}>Sign Out</button>
                        </NavLink> */}
                    </>
                ) : (
                    <p></p>
                )
            ) : (
                <p></p>
            )}
        </div>
    )
}

export default AuthDetails;