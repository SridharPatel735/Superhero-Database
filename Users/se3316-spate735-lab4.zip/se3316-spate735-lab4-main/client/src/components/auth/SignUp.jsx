// Import necessary functions and modules
import { createUserWithEmailAndPassword, sendEmailVerification } from 'firebase/auth';
import React, { useState } from 'react';
import { auth } from '../../firebase';
import sanitizeHtml from 'sanitize-html';
import './SignUp.css';

// Define the SignUp component
const SignUp = () => {
    // State variables for email, password, and username
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [userName, setUserName] = useState('');

    // Function to handle the sign-up process
    const signUp = async (e) => {
        e.preventDefault();

        // Sanitize email, password, and userName inputs
        const sanitizedEmail = sanitizeHtml(email);
        const sanitizedPassword = sanitizeHtml(password);
        const sanitizedUserName = sanitizeHtml(userName);

        try {
            // Create a new user with email and password
            const userCredential = await createUserWithEmailAndPassword(auth, sanitizedEmail, sanitizedPassword);

            // Delay before sending the verification email to avoid rate limiting
            sendEmailVerification(userCredential.user);
            console.log(userCredential);

            // Initialize adminStatus as 'No'
            let adminStatus = 'No';

            // Prepare user data for server storage
            let userData = {
                "email": userCredential.user.email,
                "username": sanitizedUserName,
                "status": "Activated",
                "JWT": "",
                "admin": adminStatus
            };

            // Send user data to the server to add a new user
            fetch(`/api/superheroes/add/user`, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(userData)
            })
            .then((response) => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json(); // Parse the response as JSON if needed
            })
            .then((responseData) => {
                // Handle the response data
                console.log(responseData);
                alert("User was added!");
            })
            .catch((error) => {
                // Handle errors
                alert(error);
            });
        } catch (error) {
            // Handle sign-up errors
            alert(error.message);
            console.log(error);
        }
    }

    // Render the SignUp component
    return (
        <div className='sign-up-container'>
            <form onSubmit={signUp}>
                <h1>Create account</h1>
                <input type="email" placeholder='Enter your email' value={email} onChange={(e) => setEmail(e.target.value)}></input>
                <input type="password" placeholder='Enter your password' value={password} onChange={(e) => setPassword(e.target.value)}></input>
                <input type="text" placeholder='Enter your username' value={userName} onChange={(e) => setUserName(e.target.value)}></input>
                <button type='submit'>Sign Up</button>
            </form>
        </div>
    )
}

// Export the SignUp component
export default SignUp;