// Import necessary functions and modules
import { signInWithEmailAndPassword, getIdToken, sendEmailVerification, updatePassword } from 'firebase/auth';
import React, { useState } from 'react';
import sanitizeHtml from 'sanitize-html';
import { auth } from '../../firebase';
import './SignIn.css';
import { NavLink } from 'react-router-dom';
import UserContext from '../../UserContext';

// Define the SignIn component
const SignIn = () => {
    // State variables for email, password, changePasswordBool, JWT token, and admin status
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [changePasswordBool, setChangePasswordBool] = useState(true);
    const [jwtToken, setJwtToken] = useState(null); // New state variable for JWT token
    const [adminStatus, setAdminStatus] = useState(false); // New state variable for JWT token
    const { setUser } = React.useContext(UserContext);

    // Function to handle the sign-in process
    const signIn = (e) => {
        e.preventDefault();

        // Sanitize email and password inputs
        const sanitizedEmail = sanitizeHtml(email);
        const sanitizedPassword = sanitizeHtml(password);

        // Sign in with email and password
        signInWithEmailAndPassword(auth, sanitizedEmail, sanitizedPassword)
            .then(async (userCredential) => {
                console.log('User Credential:', userCredential);
                const user = userCredential.user;
                let status = "Deactivated";
                setUser(user.email);

                // Check admin status from the server
                await fetch(`/api/superheroes/${user.email}/admin/status/check`)
                    .then((response) => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json(); // Parse the response as JSON if needed
                    })
                    .then((responseData) => {
                        // Handle the response data
                        console.log(responseData);
                        status = responseData.status;
                        if (responseData.admin === "No") {
                            setAdminStatus(false);
                        } else {
                            setAdminStatus(true);
                        }
                    })
                    .catch((error) => {
                        // Handle errors
                        alert(error);
                    });

                // Check if the email is verified
                if (!user.emailVerified || status === "Deactivated") {
                    if (!(status === "Activated")) {
                        alert("Your account has been deactivated. Please contact an admin to reactivate your account.");
                    } else {
                        alert('Email not verified. Please check your email and verify your account.');
                        // Optionally, provide an option to resend the verification email
                        const resendVerification = window.confirm('Resend verification email?');
                        if (resendVerification) {
                            sendEmailVerification(user);
                            alert('Verification email resent. Please check your email.');
                        }
                    }
                } else {
                    const token = await getIdToken(user);
                    // Assuming your JWT token is stored in userCredential object
                    setJwtToken(token); // Set the JWT token in the state

                    // Update JWT token on the server
                    let userData = {
                        "inputEmail": user.email,
                        "inputToken": token
                    };
                    fetch(`/api/superheroes/update/JWT`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(userData)
                    })
                        .then((response) => {
                            if (!response.ok) {
                                throw new Error('Network response was not ok');
                            }
                            return response.json(); // Parse the response as JSON if needed
                        })
                        .then((responseData) => {
                            // Handle the response data
                            alert("ID's were added!");
                        })
                        .catch((error) => {
                            // Handle errors
                            alert(error);
                        });
                }
            })
            .catch((error) => {
                // Handle sign-in errors
                alert(error.message);
                console.log(error);
            });
    }

    // Function to handle password change
    const changePassword = async () => {
        const user = auth.currentUser;

        // Check if the user is signed in and email is verified before allowing password change
        if (user && user.emailVerified) {
            const newPassword = password;

            // Update the password
            try {
                updatePassword(user, newPassword);
                setChangePasswordBool(false);
                alert('Password changed successfully!');
            } catch (error) {
                alert(error.message);
            }
        } else {
            alert('User not signed in or email not verified.');
        }
    };

    // Render the SignIn component
    return (
        <div className='sign-in-container'>
            <form onSubmit={signIn}>
                <h1>Log into your account</h1>
                <input type="email" placeholder='Enter your email' value={email} onChange={(e) => setEmail(e.target.value)}></input>
                <input type="password" placeholder='Enter your password' value={password} onChange={(e) => setPassword(e.target.value)}></input>
                <button type='submit'>Log In</button>
                {jwtToken && changePasswordBool && (
                    <>
                        {/* Display instructions for updating the password */}
                        <p>Update the password field and press change password to update password.</p>
                        <button type='button' onClick={changePassword}>Change Password</button>
                        {/* Display admin or user home page links based on admin status */}
                        {adminStatus && (
                            <NavLink to="/admin-home-page">
                                <button>Go to admin home page</button>
                            </NavLink>
                        )}
                        {!adminStatus && (
                            <NavLink to="/user-home-page">
                                <button>Go to user home page</button>
                            </NavLink>
                        )}
                    </>
                )}
            </form>
        </div>
    )
}

// Export the SignIn component
export default SignIn;