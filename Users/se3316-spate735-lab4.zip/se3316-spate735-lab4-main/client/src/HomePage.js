import React from 'react';
import './HomePage.css';
import HeroSearch from './HeroSearch';
import SignIn from './components/auth/SignIn';
import SignUp from './components/auth/SignUp';
import AuthDetails from './components/AuthDetails';

// Home page component
const HomePage = () => {
  return (
    <div className="app-container">
      <h1>Sridhar's Superhero Storage</h1>
      <p>Welcome to my superhero DB!!!</p>
      <h1>Login!</h1>
      <SignIn />
      <h1>Sign up!</h1>
      <SignUp />
      <AuthDetails />
      <HeroSearch />
    </div>
  );
};

export default HomePage;