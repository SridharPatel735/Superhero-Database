import React from "react";
import "./AdminHomePage.css";
import { NavLink } from "react-router-dom";

function AdminHomePage() {
    // Function to fetch and list all users in the dropdown
    function listUsers() {
        fetch(`/api/superheroes/get/all/users`)
            .then((response) => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json(); // Parse the response as JSON
            })
            .then((responseData) => {
                // Handle the response data
                let dropDown = document.getElementById("listOption");

                // Clear existing options in the dropdown
                let i;
                let length = dropDown.options.length - 1;
                for (i = length; i >= 0; i--) {
                    dropDown.remove(i);
                }

                // Populate dropdown with user emails
                console.log("data:", responseData);
                for (let index of responseData) {
                    if (!(index.admin == "mainAdmin")) {
                        let option = document.createElement("option");
                        option.textContent = index.email;
                        option.value = index.email;
                        dropDown.appendChild(option);
                    }
                }
            })
            .catch((error) => {
                alert(error);
            });
    }

    // Function to update the admin status of a user
    function adminUpdate(input) {
        let listOption = document.getElementById('listOption');
        let userData = {
            "inputEmail": listOption.value,
            "adminStatus": input
        }
        fetch(`/api/superheroes/update/adminStatus`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(userData)
        })
            .then((response) => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json(); // Parse the response as JSON
            })
            .then((responseData) => {
                // Handle the response data
                console.log("data:", responseData);
                alert("User updated successfully!")
            })
            .catch((error) => {
                alert(error);
            });
    }

    // Function to update the active status of a user
    function statusUpdate(input) {
        let listOption = document.getElementById('listOption');
        let userData = {
            "inputEmail": listOption.value,
            "activeStatus": input
        }
        console.log(userData);
        fetch(`/api/superheroes/update/activeStatus`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(userData)
        })
            .then((response) => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json(); // Parse the response as JSON
            })
            .then((responseData) => {
                // Handle the response data
                console.log("data:", responseData);
                alert("User updated successfully!")
            })
            .catch((error) => {
                alert(error);
            });
    }

    return (
        <div className="user-home-page" onLoad={listUsers()}>
            <h1>Admin Home Page</h1>
            <header className="App-header">
                <select id="listOption">
                </select>
            </header>
            <div className="createList">
                <button id="addAdmin" onClick={() => adminUpdate("Admin")}>Add admin</button>
                <button id="removeAdmin" onClick={() => adminUpdate("No")}>Remove admin</button>
                <button id="disableUser" onClick={() => statusUpdate("Deactivated")}>Disable user</button>
                <button id="enableUser" onClick={() => statusUpdate("Activated")}>Enable user</button>
                <NavLink to="/">
                    <button>Go to home page</button>
                </NavLink>
            </div>
        </div>
    );
}

export default AdminHomePage;