import React from 'react';

// Create a context object
const UserContext = React.createContext(null);

export default UserContext;