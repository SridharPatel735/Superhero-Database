const express = require("express");
const PORT = process.env.PORT || 3001;
const app = express();
const mongoose = require('mongoose');
const fs = require('fs');
const router = express.Router();
const path = require('path');

router.use(express.json());

mongoose.connect('mongodb://localhost:27017/superheroes');
const mongodb = mongoose.connection;
mongodb.on('error', console.error.bind(console, 'MongoDB connection error:'));
mongodb.once('open', () => {console.log('Connected to MongoDB');});

//SuperheroInfo schema
const superInfoSchema = new mongoose.Schema({
    "id" : Number,
    "name" : String,
    "Gender" : String,
    "Eye color" : String,
    "Race" : String,
    "Hair color" : String,
    "Height" : Number,
    "Publisher" : String,
    "Skin color" : String,
    "Alignment" : String,
    "Weight" : Number,
})
const superInfo = mongoose.model('superHeroInfo', superInfoSchema);
module.exports = (superInfo);

//Combined superhero schema
const superListSchema = new mongoose.Schema({
    "id" : Number,
    "name" : String,
    "Gender" : String,
    "Eye color" : String,
    "Race" : String,
    "Hair color" : String,
    "Height" : Number,
    "Publisher" : String,
    "Skin color" : String,
    "Alignment" : String,
    "Weight" : Number,
    "Agility" : String,
    "Accelerated Healing" : String,
    "Lantern Power Ring" : String,
    "Dimensional Awareness" : String,
    "Cold Resistance" : String,
    "Durability" : String,
    "Stealth" : String,
    "Energy Absorption" : String,
    "Flight" : String,
    "Danger Sense" : String,
    "Underwater breathing" : String,
    "Marksmanship" : String,
    "Weapons Master" : String,
    "Power Augmentation" : String,
    "Animal Attributes" : String,
    "Longevity" : String,
    "Intelligence" : String,
    "Super Strength" : String,
    "Cryokinesis" : String,
    "Telepathy" : String,
    "Energy Armor" : String,
    "Energy Blasts" : String,
    "Duplication" : String,
    "Size Changing" : String,
    "Density Control" : String,
    "Stamina" : String,
    "Astral Travel" : String,
    "Audio Control" : String,
    "Dexterity" : String,
    "Omnitrix" : String,
    "Super Speed" : String,
    "Possession" : String,
    "Animal Oriented Powers" : String,
    "Weapon-based Powers" : String,
    "Electrokinesis" : String,
    "Darkforce Manipulation" : String,
    "Death Touch" : String,
    "Teleportation" : String,
    "Enhanced Senses" : String,
    "Telekinesis" : String,
    "Energy Beams" : String,
    "Magic" : String,
    "Hyperkinesis" : String,
    "Jump" : String,
    "Clairvoyance" : String,
    "Dimensional Travel" : String,
    "Power Sense" : String,
    "Shapeshifting" : String,
    "Peak Human Condition" : String,
    "Immortality" : String,
    "Camouflage" : String,
    "Element Control" : String,
    "Phasing" : String,
    "Astral Projection" : String,
    "Electrical Transport" : String,
    "Fire Control" : String,
    "Projection" : String,
    "Summoning" : String,
    "Enhanced Memory" : String,
    "Reflexes" : String,
    "Invulnerability" : String,
    "Energy Constructs" : String,
    "Force Fields" : String,
    "Self-Sustenance" : String,
    "Anti-Gravity" : String,
    "Empathy" : String,
    "Power Nullifier" : String,
    "Radiation Control" : String,
    "Psionic Powers" : String,
    "Elasticity" : String,
    "Substance Secretion" : String,
    "Elemental Transmogrification" : String,
    "Technopath/Cyberpath" : String,
    "Photographic Reflexes" : String,
    "Seismic Power" : String,
    "Animation" : String,
    "Precognition" : String,
    "Mind Control" : String,
    "Fire Resistance" : String,
    "Power Absorption" : String,
    "Enhanced Hearing" : String,
    "Nova Force" : String,
    "Insanity" : String,
    "Hypnokinesis" : String,
    "Animal Control" : String,
    "Natural Armor" : String,
    "Intangibility" : String,
    "Enhanced Sight" : String,
    "Molecular Manipulation" : String,
    "Heat Generation" : String,
    "Adaptation" : String,
    "Gliding" : String,
    "Power Suit" : String,
    "Mind Blast" : String,
    "Probability Manipulation" : String,
    "Gravity Control" : String,
    "Regeneration" : String,
    "Light Control" : String,
    "Echolocation" : String,
    "Levitation" : String,
    "Toxin and Disease Control" : String,
    "Banish" : String,
    "Energy Manipulation" : String,
    "Heat Resistance" : String,
    "Natural Weapons" : String,
    "Time Travel" : String,
    "Enhanced Smell" : String,
    "Illusions" : String,
    "Thirstokinesis" : String,
    "Hair Manipulation" : String,
    "Illumination" : String,
    "Omnipotent" : String,
    "Cloaking" : String,
    "Changing Armor" : String,
    "Power Cosmic" : String,
    "Biokinesis" : String,
    "Water Control" : String,
    "Radiation Immunity" : String,
    "Vision - Telescopic" : String,
    "Toxin and Disease Resistance" : String,
    "Spatial Awareness" : String,
    "Energy Resistance" : String,
    "Telepathy Resistance" : String,
    "Molecular Combustion" : String,
    "Omnilingualism" : String,
    "Portal Creation" : String,
    "Magnetism" : String,
    "Mind Control Resistance" : String,
    "Plant Control" : String,
    "Sonar" : String,
    "Sonic Scream" : String,
    "Time Manipulation" : String,
    "Enhanced Touch" : String,
    "Magic Resistance" : String,
    "Invisibility" : String,
    "Sub-Mariner" : String,
    "Radiation Absorption" : String,
    "Intuitive aptitude" : String,
    "Vision - Microscopic" : String,
    "Melting" : String,
    "Wind Control" : String,
    "Super Breath" : String,
    "Wallcrawling" : String,
    "Vision - Night" : String,
    "Vision - Infrared" : String,
    "Grim Reaping" : String,
    "Matter Absorption" : String,
    "The Force" : String,
    "Resurrection" : String,
    "Terrakinesis" : String,
    "Vision - Heat" : String,
    "Vitakinesis" : String,
    "Radar Sense" : String,
    "Qwardian Power Ring" : String,
    "Weather Control" : String,
    "Vision - X-Ray" : String,
    "Vision - Thermal" : String,
    "Web Creation" : String,
    "Reality Warping" : String,
    "Odin Force" : String,
    "Symbiote Costume" : String,
    "Speed Force" : String,
    "Phoenix Force" : String,
    "Molecular Dissipation" : String,
    "Vision - Cryo" : String,
    "Omnipresent" : String,
    "Omniscient" : String,
})

const userSchema = new mongoose.Schema({
    "email" : String,
    "username" : String,
    "status" : String,
    "JWT" : String,
    "admin" : String,
})
const userCollection = mongoose.model('users', userSchema);
module.exports = (userCollection);

//SuperheroPower schema
const superPowerSchema = new mongoose.Schema({
    "hero_names" : String,
    "Agility" : String,
    "Accelerated Healing" : String,
    "Lantern Power Ring" : String,
    "Dimensional Awareness" : String,
    "Cold Resistance" : String,
    "Durability" : String,
    "Stealth" : String,
    "Energy Absorption" : String,
    "Flight" : String,
    "Danger Sense" : String,
    "Underwater breathing" : String,
    "Marksmanship" : String,
    "Weapons Master" : String,
    "Power Augmentation" : String,
    "Animal Attributes" : String,
    "Longevity" : String,
    "Intelligence" : String,
    "Super Strength" : String,
    "Cryokinesis" : String,
    "Telepathy" : String,
    "Energy Armor" : String,
    "Energy Blasts" : String,
    "Duplication" : String,
    "Size Changing" : String,
    "Density Control" : String,
    "Stamina" : String,
    "Astral Travel" : String,
    "Audio Control" : String,
    "Dexterity" : String,
    "Omnitrix" : String,
    "Super Speed" : String,
    "Possession" : String,
    "Animal Oriented Powers" : String,
    "Weapon-based Powers" : String,
    "Electrokinesis" : String,
    "Darkforce Manipulation" : String,
    "Death Touch" : String,
    "Teleportation" : String,
    "Enhanced Senses" : String,
    "Telekinesis" : String,
    "Energy Beams" : String,
    "Magic" : String,
    "Hyperkinesis" : String,
    "Jump" : String,
    "Clairvoyance" : String,
    "Dimensional Travel" : String,
    "Power Sense" : String,
    "Shapeshifting" : String,
    "Peak Human Condition" : String,
    "Immortality" : String,
    "Camouflage" : String,
    "Element Control" : String,
    "Phasing" : String,
    "Astral Projection" : String,
    "Electrical Transport" : String,
    "Fire Control" : String,
    "Projection" : String,
    "Summoning" : String,
    "Enhanced Memory" : String,
    "Reflexes" : String,
    "Invulnerability" : String,
    "Energy Constructs" : String,
    "Force Fields" : String,
    "Self-Sustenance" : String,
    "Anti-Gravity" : String,
    "Empathy" : String,
    "Power Nullifier" : String,
    "Radiation Control" : String,
    "Psionic Powers" : String,
    "Elasticity" : String,
    "Substance Secretion" : String,
    "Elemental Transmogrification" : String,
    "Technopath/Cyberpath" : String,
    "Photographic Reflexes" : String,
    "Seismic Power" : String,
    "Animation" : String,
    "Precognition" : String,
    "Mind Control" : String,
    "Fire Resistance" : String,
    "Power Absorption" : String,
    "Enhanced Hearing" : String,
    "Nova Force" : String,
    "Insanity" : String,
    "Hypnokinesis" : String,
    "Animal Control" : String,
    "Natural Armor" : String,
    "Intangibility" : String,
    "Enhanced Sight" : String,
    "Molecular Manipulation" : String,
    "Heat Generation" : String,
    "Adaptation" : String,
    "Gliding" : String,
    "Power Suit" : String,
    "Mind Blast" : String,
    "Probability Manipulation" : String,
    "Gravity Control" : String,
    "Regeneration" : String,
    "Light Control" : String,
    "Echolocation" : String,
    "Levitation" : String,
    "Toxin and Disease Control" : String,
    "Banish" : String,
    "Energy Manipulation" : String,
    "Heat Resistance" : String,
    "Natural Weapons" : String,
    "Time Travel" : String,
    "Enhanced Smell" : String,
    "Illusions" : String,
    "Thirstokinesis" : String,
    "Hair Manipulation" : String,
    "Illumination" : String,
    "Omnipotent" : String,
    "Cloaking" : String,
    "Changing Armor" : String,
    "Power Cosmic" : String,
    "Biokinesis" : String,
    "Water Control" : String,
    "Radiation Immunity" : String,
    "Vision - Telescopic" : String,
    "Toxin and Disease Resistance" : String,
    "Spatial Awareness" : String,
    "Energy Resistance" : String,
    "Telepathy Resistance" : String,
    "Molecular Combustion" : String,
    "Omnilingualism" : String,
    "Portal Creation" : String,
    "Magnetism" : String,
    "Mind Control Resistance" : String,
    "Plant Control" : String,
    "Sonar" : String,
    "Sonic Scream" : String,
    "Time Manipulation" : String,
    "Enhanced Touch" : String,
    "Magic Resistance" : String,
    "Invisibility" : String,
    "Sub-Mariner" : String,
    "Radiation Absorption" : String,
    "Intuitive aptitude" : String,
    "Vision - Microscopic" : String,
    "Melting" : String,
    "Wind Control" : String,
    "Super Breath" : String,
    "Wallcrawling" : String,
    "Vision - Night" : String,
    "Vision - Infrared" : String,
    "Grim Reaping" : String,
    "Matter Absorption" : String,
    "The Force" : String,
    "Resurrection" : String,
    "Terrakinesis" : String,
    "Vision - Heat" : String,
    "Vitakinesis" : String,
    "Radar Sense" : String,
    "Qwardian Power Ring" : String,
    "Weather Control" : String,
    "Vision - X-Ray" : String,
    "Vision - Thermal" : String,
    "Web Creation" : String,
    "Reality Warping" : String,
    "Odin Force" : String,
    "Symbiote Costume" : String,
    "Speed Force" : String,
    "Phoenix Force" : String,
    "Molecular Dissipation" : String,
    "Vision - Cryo" : String,
    "Omnipresent" : String,
    "Omniscient" : String,
})
const superPower = mongoose.model('superPowers', superPowerSchema);
module.exports = (superPower);

//If file needs to be loaded onto the server
async function loadInfo(fileName){
    const fullPath = path.join(__dirname, "..", fileName);
    console.log(fullPath);

    const data = JSON.parse(fs.readFileSync(fullPath, 'utf-8'));
    // Insert each superhero into the database using await.
    for (const superhero of data) {
        const newSuperhero = new superInfo(superhero); // Use the 'superInfo' Mongoose model
        await newSuperhero.save(); // Use await to handle the promise returned by save().
    }
}

//If file needs to be loaded onto the server
async function loadPower(fileName){
    const fullPath = path.join(__dirname, "..", fileName);
    console.log(fullPath);

    const data = JSON.parse(fs.readFileSync(fullPath, 'utf-8'));
    // Insert each superhero into the database using await.
    for (const superhero of data) {
        const newSuperhero = new superPower(superhero); // Use the 'superPower' Mongoose model
        await newSuperhero.save(); // Use await to handle the promise returned by save().
    }
}

//PUT method where user selects id's and listname to add and replace previous data.
router.put('/:listName', async (req, res) => {
    const rqListName = req.params.listName;
    const rqListIndexes = req.body;
    try{
        //Deleting everything that was there
        await mongodb.collection(`${rqListName}`).deleteMany({});

        //Finding info for each id
        for (let index of rqListIndexes){
            const info = await superInfo.findOne({id:index}).select("-_id -__v").lean();
            let powers = await superPower.findOne({hero_names:info.name}).select("-_id -__v -hero_names").lean();

            try {
                if (powers == null) {
                    powers = await superPower.findOne({hero_names:"3-D Man"}).select("-_id -__v -hero_names").lean();
                    for (let attr in powers) {
                        powers[attr] = "False";
                    }
                }
            } 
            catch (errors) {
                console.log(errors);
            }

            const superList = mongoose.model(`${rqListName}`, superListSchema, `${rqListName}`);

            const newHero = new superList({
                id: info.id,
                name: info.name,
                Gender: info.Gender,
                'Eye color': info['Eye color'],
                Race: info.Race,
                'Hair color': info['Hair color'],
                Height: info.Height,
                Publisher: info.Publisher,
                'Skin color': info['Skin color'],
                Alignment: info.Alignment,
                Weight: info.Weight,
                Agility: powers.Agility,
                'Accelerated Healing': powers['Accelerated Healing'],
                'Lantern Power Ring': powers['Lantern Power Ring'],
                'Dimensional Awareness': powers['Dimensional Awareness'],
                'Cold Resistance': powers['Cold Resistance'],
                Durability: powers.Durability,
                Stealth: powers.Stealth,
                'Energy Absorption': powers['Energy Absorption'],
                Flight: powers.Flight,
                'Danger Sense': powers['Danger Sense'],
                'Underwater breathing': powers['Underwater breathing'],
                Marksmanship: powers.Marksmanship,
                'Weapons Master': powers['Weapons Master'],
                'Power Augmentation': powers['Power Augmentation'],
                'Animal Attributes': powers['Animal Attributes'],
                Longevity: powers.Longevity,
                Intelligence: powers.Intelligence,
                'Super Strength': powers['Super Strength'],
                Cryokinesis: powers.Cryokinesis,
                Telepathy: powers.Telepathy,
                'Energy Armor': powers['Energy Armor'],
                'Energy Blasts': powers['Energy Blasts'],
                Duplication: powers.Duplication,
                'Size Changing': powers['Size Changing'],
                'Density Control': powers['Density Control'],
                Stamina: powers.Stamina,
                'Astral Travel': powers['Astral Travel'],
                'Audio Control': powers['Audio Control'],
                Dexterity: powers.Dexterity,
                Omnitrix: powers.Omnitrix,
                'Super Speed': powers['Super Speed'],
                Possession: powers.Possession,
                'Animal Oriented Powers': powers['Animal Oriented Powers'],
                'Weapon-based Powers': powers['Weapon-based Powers'],
                Electrokinesis: powers.Electrokinesis,
                'Darkforce Manipulation': powers['Darkforce Manipulation'],
                'Death Touch': powers['Death Touch'],
                Teleportation: powers.Teleportation,
                'Enhanced Senses': powers['Enhanced Senses'],
                Telekinesis: powers.Telekinesis,
                'Energy Beams': powers['Energy Beams'],
                Magic: powers.Magic,
                Hyperkinesis: powers.Hyperkinesis,
                Jump: powers.Jump,
                Clairvoyance: powers.Clairvoyance,
                'Dimensional Travel': powers['Dimensional Travel'],
                'Power Sense': powers['Power Sense'],
                Shapeshifting: powers.Shapeshifting,
                'Peak Human Condition': powers['Peak Human Condition'],
                Immortality: powers.Immortality,
                Camouflage: powers.Camouflage,
                'Element Control': powers['Element Control'],
                Phasing: powers.Phasing,
                'Astral Projection': powers['Astral Projection'],
                'Electrical Transport': powers['Electrical Transport'],
                'Fire Control': powers['Fire Control'],
                Projection: powers.Projection,
                Summoning: powers.Summoning,
                'Enhanced Memory': powers['Enhanced Memory'],
                Reflexes: powers.Reflexes,
                Invulnerability: powers.Invulnerability,
                'Energy Constructs': powers['Energy Constructs'],
                'Force Fields': powers['Force Fields'],
                'Self-Sustenance': powers['Self-Sustenance'],
                'Anti-Gravity': powers['Anti-Gravity'],
                Empathy: powers.Empathy,
                'Power Nullifier': powers['Power Nullifier'],
                'Radiation Control': powers['Radiation Control'],
                'Psionic Powers': powers['Psionic Powers'],
                Elasticity: powers.Elasticity,
                'Substance Secretion': powers['Substance Secretion'],
                'Elemental Transmogrification': powers['Elemental Transmogrification'],
                'Technopath/Cyberpath': powers['Technopath/Cyberpath'],
                'Photographic Reflexes': powers['Photographic Reflexes'],
                'Seismic Power': powers['Seismic Power'],
                Animation: powers.Animation,
                Precognition: powers.Precognition,
                'Mind Control': powers['Mind Control'],
                'Fire Resistance': powers['Fire Resistance'],
                'Power Absorption': powers['Power Absorption'],
                'Enhanced Hearing': powers['Enhanced Hearing'],
                'Nova Force': powers['Nova Force'],
                Insanity: powers.Insanity,
                Hypnokinesis: powers.Hypnokinesis,
                'Animal Control': powers['Animal Control'],
                'Natural Armor': powers['Natural Armor'],
                Intangibility: powers.Intangibility,
                'Enhanced Sight': powers['Enhanced Sight'],
                'Molecular Manipulation': powers['Molecular Manipulation'],
                'Heat Generation': powers['Heat Generation'],
                Adaptation: powers.Adaptation,
                Gliding: powers.Gliding,
                'Power Suit': powers['Power Suit'],
                'Mind Blast': powers['Mind Blast'],
                'Probability Manipulation': powers['Probability Manipulation'],
                'Gravity Control': powers['Gravity Control'],
                Regeneration: powers.Regeneration,
                'Light Control': powers['Light Control'],
                Echolocation: powers.Echolocation,
                Levitation: powers.Levitation,
                'Toxin and Disease Control': powers['Toxin and Disease Control'],
                Banish: powers.Banish,
                'Energy Manipulation': powers['Energy Manipulation'],
                'Heat Resistance': powers['Heat Resistance'],
                'Natural Weapons': powers['Natural Weapons'],
                'Time Travel': powers['Time Travel'],
                'Enhanced Smell': powers['Enhanced Smell'],
                Illusions: powers.Illusions,
                Thirstokinesis: powers.Thirstokinesis,
                'Hair Manipulation': powers['Hair Manipulation'],
                Illumination: powers.Illumination,
                Omnipotent: powers.Omnipotent,
                Cloaking: powers.Cloaking,
                'Changing Armor': powers['Changing Armor'],
                'Power Cosmic': powers['Power Cosmic'],
                Biokinesis: powers.Biokinesis,
                'Water Control': powers['Water Control'],
                'Radiation Immunity': powers['Radiation Immunity'],
                'Vision - Telescopic': powers['Vision - Telescopic'],
                'Toxin and Disease Resistance': powers['Toxin and Disease Resistance'],
                'Spatial Awareness': powers['Spatial Awareness'],
                'Energy Resistance': powers['Energy Resistance'],
                'Telepathy Resistance': powers['Telepathy Resistance'],
                'Molecular Combustion': powers['Molecular Combustion'],
                Omnilingualism: powers.Omnilingualism,
                'Portal Creation': powers['Portal Creation'],
                Magnetism: powers.Magnetism,
                'Mind Control Resistance': powers['Mind Control Resistance'],
                'Plant Control': powers['Plant Control'],
                Sonar: powers.Sonar,
                'Sonic Scream': powers['Sonic Scream'],
                'Time Manipulation': powers['Time Manipulation'],
                'Enhanced Touch': powers['Enhanced Touch'],
                'Magic Resistance': powers['Magic Resistance'],
                Invisibility: powers.Invisibility,
                'Sub-Mariner': powers['Sub-Mariner'],
                'Radiation Absorption': powers['Radiation Absorption'],
                'Intuitive aptitude': powers['Intuitive aptitude'],
                'Vision - Microscopic': powers['Vision - Microscopic'],
                Melting: powers.Melting,
                'Wind Control': powers['Wind Control'],
                'Super Breath': powers['Super Breath'],
                Wallcrawling: powers.Wallcrawling,
                'Vision - Night': powers['Vision - Night'],
                'Vision - Infrared': powers['Vision - Infrared'],
                'Grim Reaping': powers['Grim Reaping'],
                'Matter Absorption': powers['Matter Absorption'],
                'The Force': powers['The Force'],
                Resurrection: powers.Resurrection,
                Terrakinesis: powers.Terrakinesis,
                'Vision - Heat': powers['Vision - Heat'],
                Vitakinesis: powers.Vitakinesis,
                'Radar Sense': powers['Radar Sense'],
                'Qwardian Power Ring': powers['Qwardian Power Ring'],
                'Weather Control': powers['Weather Control'],
                'Vision - X-Ray': powers['Vision - X-Ray'],
                'Vision - Thermal': powers['Vision - Thermal'],
                'Web Creation': powers['Web Creation'],
                'Reality Warping': powers['Reality Warping'],
                'Odin Force': powers['Odin Force'],
                'Symbiote Costume': powers['Symbiote Costume'],
                'Speed Force': powers['Speed Force'],
                'Phoenix Force': powers['Phoenix Force'],
                'Molecular Dissipation': powers['Molecular Dissipation'],
                'Vision - Cryo': powers['Vision - Cryo'],
                Omnipresent: powers.Omnipresent,
                Omniscient: powers.Omniscient,
            });

            newHero.save();
        }
        res.json(`ID: ${rqListIndexes} were added to table: ${rqListName}!`);
    }
    catch(errors){
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

//PUT method where it updates JWT with email
router.put('/update/JWT', async (req, res) => {
    const {inputEmail, inputToken} = req.body;
    try {
        await userCollection.updateOne({ email: inputEmail }, { $set: { JWT: inputToken } });
        res.status(201).json({ message: 'User Status and JWT Updated' });
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

//PUT method where it updates admin status with email
router.put('/update/adminStatus', async (req, res) => {
    const {inputEmail, adminStatus} = req.body;
    try {
        await userCollection.updateOne({ email: inputEmail }, { $set: { admin: adminStatus } });
        res.status(200).json({ message: 'Admin status updated' });
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

//PUT method where it updates active status with email
router.put('/update/activeStatus', async (req, res) => {
    const {inputEmail, activeStatus} = req.body;
    try {
        await userCollection.updateOne({ email: inputEmail }, { $set: { status: activeStatus } });
        res.status(200).json({ message: 'Active status updated' });
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

//POST method where it enters new user into DB
router.post('/add/user', async (req, res) => {
    const userInfo = req.body;
    try{
        const instance = new userCollection(userInfo);
        instance.save()

        res.json(`Added: ${userInfo}!`);
    }
    catch(errors){
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

//POST method where user enters listname to create
router.post('/:listName', async (req, res) => {
    const rqListName = req.params.listName;
    let createList = true;

    //Getting all current listnames
    const collections = await mongoose.connection.db.listCollections().toArray();
    const collectionNames = collections.map((c) => c.name);

    //Checking if name already exists if it doesn't then create it
    if (collectionNames.includes(rqListName)){
        createList = false;
    }
    if (createList) {
        const superList = mongoose.model(`${rqListName}`, superListSchema, `${rqListName}`);
        module.exports = superList;
        res.send({ message: `List ${rqListName} has been created!` });
    }
    else{
        res.send({ error: 'List name already exists' });
    }
});

//DELETE method which deletes list when user sends name
router.delete('/:listName/deleteList', async (req, res) => {
    const listName = req.params.listName;

    try {
        // Get a list of all collection names in the database
        const collections = await mongoose.connection.db.listCollections().toArray();
        const collectionNames = collections.map((c) => c.name);

        // Check if the desired collection name exists
        if (collectionNames.includes(listName)) {
            // Use Mongoose's connection object to drop the collection
            await mongoose.connection.dropCollection(listName);

            res.status(200).json({ message: `Collection ${listName} has been deleted.`});

        } else {
            res.status(404).json({ message: `Collection ${listName} does not exist.`});
        }
    } catch (error) {
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

//Getting user status with email
router.get('/:email/admin/status/check', async (req, res) => {
    const rqEmail = req.params.email;
    try{
        const info = await userCollection.findOne({email:rqEmail}).select("-_id -__v").lean();
        if(!info){
            return res.status(404).json({error: `User with email:${rqEmail} does not exist`});
        }
        res.status(200).json(info);
    }
    catch(error){
        return res.status(500).json({message:error});
    }
});

//Getting user status with email
router.get('/get/all/users', async (req, res) => {
    try{
        const info = await userCollection.find({}).select("-_id -__v").lean();
        res.status(200).json(info);
    }
    catch(error){
        return res.status(500).json({message:error});
    }
});

//Getting all info of heroes in a certain list
router.get('/:listName/allInfo', async (req, res) => {
    try{
        const rqListName = req.params.listName;

        const givenList = mongoose.model(`${rqListName}`, superListSchema, `${rqListName}`);

        const info = await givenList.find({}).select("-_id -__v").lean();

        const heroesArray = [];

        //Getting all info and only powers which are true
        for (const hero of info) {
            const superHeroPowers = {};
            for (const index in hero) {
                if (hero[index] !== "False") {
                    superHeroPowers[index] = hero[index];
                }
            }
            heroesArray.push(superHeroPowers);
        }

        if(!info){
            return res.status(404).json({error: `No heroes in ${rqListName} server`});
        }
        res.status(200).json(heroesArray);
    }

    catch(error){
        return res.status(500).json({message:error});
    }
});

//Getting all id's in a certain list
router.get('/:listName/id', async (req, res) => {
    try{
        const rqListName = req.params.listName;

        const givenList = mongoose.model(`${rqListName}`, superListSchema, `${rqListName}`);

        //Only selecting the id element for each hero
        const info = await givenList.find({}).select("id -_id").lean();

        if(!info){
            return res.status(404).json({error: `No heroes in ${rqListName} server`});
        }
        res.status(200).json(info);
    }

    catch(error){
        return res.status(500).json({message:error});
    }
});

//Getting all tablenames in the DB
router.get('/tableNames', async (req, res) => {
    const collections = await mongoose.connection.db.listCollections().toArray();
    const collectionNames = collections.map((c) => c.name);
    res.json(collectionNames);
});

//Match function which takes the field, pattern, then number of results
router.get('/:field/:pattern/:n', async (req, res) => {
    try{
        const field = req.params.field;
        const pattern = req.params.pattern;
        const n = req.params.n;
        let info = 0;
        let projection = {
            _id: 0,
            __v: 0
        };

        //Allows for partial search
        const rqPattern = new RegExp(`^${pattern}`, 'i');

        if (field == 'Height' || field == 'Weight'){
            info = await superInfo.aggregate([{$match: {[field] : parseInt(rqPattern)}}, {$limit: parseInt(n)}, {$project: projection}]);
        }
        else{
            info = await superInfo.aggregate([{$match: {[field] : rqPattern}}, {$limit: parseInt(n)},  {$project: projection}]);
        }
        
        if(info.length == 0){
            return res.status(404).json({error: `Given the criteria of ${field}, ${rqPattern}, and ${n}. There are no results!`});
        }
        res.status(200).json(info);
    }
    catch(error){
        return res.status(500).json({message:error});
    }
});

//Getting all the publishers
router.get('/publishers', async (req, res) => {
    try{
        //Getting distinct publishers so no repeating
        const publishers = await superInfo.distinct('Publisher');
        const filterPublishers = publishers.filter(name => name !== "");

        res.status(200).json(filterPublishers);
    }
    catch(error){
        return res.status(500).json({message:error});
    }
}); 

//Getting all hero's info
router.get('/', async (req, res) => {
    try{
        //Getting all hero's info from superheroInfo list
        const info = await superInfo.find({}).select("-_id -__v").lean();

        if(!info){
            return res.status(404).json({error: `Error extracting hero info`});
        }
        res.status(200).json(info);
    }

    catch(error){
        return res.status(500).json({message:error});
    }
});

//Getting all info for a hero from a given ID
router.get('/:id', async (req, res) => {
    try{
        const rqID = req.params.id;
        //Only finding one since ID is unique
        const info = await superInfo.findOne({id:rqID}).select("-_id -__v").lean();

        if(!info){
            return res.status(404).json({error: `Hero with id:${rqID} does not exist`});
        }
        res.status(200).json(info);
    }

    catch(error){
        return res.status(500).json({message:error});
    }
});

//Getting all power info for a given ID
router.get('/:id/powers', async (req, res) => {
    try{
        const rqID = req.params.id;

        //Finding name with the ID
        const info = await superInfo.findOne({id:rqID}).select("-_id -__v").lean();
        
        if(!info){
            return res.send({error: `Hero with id:${rqID} does not exist`});
        }

        //Using name to get all powers and then only returning the "true" powers
        const powers = await superPower.findOne({hero_names:info.name}).select("-_id -__v").lean();

        if(!powers){
            return res.send({error: `Hero with id:${rqID} does not have any powers`});
        }

        const superPowers = {}

        for (let power in powers){
            if (powers[power] === "True"){
                superPowers[power] = true;
            }
        }

        res.status(200).json(superPowers);
    }

    catch (error){
        return res.status(500).json({message:error});
    }
});

//Getting hero info with name
router.get('/:name/result', async (req, res) => {
    try{
        const rqName = decodeURIComponent(req.params.name);
        const rqSearchName = new RegExp('^' + rqName, 'i');

        //Finding one specific hero
        const info = await superInfo.find({name:rqSearchName}).select("-_id -__v");

        if(!info){
            return res.status(404).json({error: `Hero with name:${rqName} does not exist`});
        }
        res.status(200).json(info);
    }

    catch(error){
        return res.status(500).json({message:error});
    }
});

router.get('/everyHero/allInfo/search/power', async (req, res) => {
    try{
        const info = await superInfo.find({}).select("-_id -__v").lean();
        const result = []
        for (const hero of info){
            //Using name to get all powers and then only returning the "true" powers
            const powers = await superPower.findOne({hero_names: hero.name}).select("-_id -__v").lean();
            stats = {
                id: hero.id,
                name: hero.name,
                Gender: hero.Gender,
                'Eye color': hero['Eye color'],
                Race: hero.Race,
                'Hair color': hero['Hair color'],
                Height: hero.Height,
                Publisher: hero.Publisher,
                'Skin color': hero['Skin color'],
                Alignment: hero.Alignment,
                Weight: hero.Weight,
                Powers: []
            }

            if (powers){
                for (p in powers){
                    if (powers[p] === 'True'){
                        stats.Powers.push(p)
                    }
                }
                result.push(stats)
            }
            else{
                stats.Powers.push('None')
                result.push(stats)
            }
        }
        res.status(200).json(result);
    }

    catch (error){
        return res.status(500).json({message:error});
    }
});

//Using router to avoid repeating code
app.use('/api/superheroes', router);

app.get("/api", (req, res) => {
    res.json({ message: "AHAHA" });
});

app.listen(PORT, () => {
    console.log(`Server listening on ${PORT}`);
});