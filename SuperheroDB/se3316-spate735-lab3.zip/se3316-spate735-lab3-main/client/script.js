//Adding event listeners()
document.getElementById('heroSearch').addEventListener('click', heroSearch);
document.getElementById('addList').addEventListener('click', createList);
document.getElementById('listInfo').addEventListener('click', listInfo);
document.getElementById('deleteList').addEventListener('click', deleteList);
document.getElementById('addIDList').addEventListener('click', addIDList);
document.getElementById('idInfo').addEventListener('click', idList);
document.getElementById('nameSort').addEventListener('click', nameSortMethod);
document.getElementById('raceSort').addEventListener('click', raceSortMethod);
document.getElementById('publisherSort').addEventListener('click', publisherSortMethod);
document.getElementById('powerSort').addEventListener('click', powerSortMethod);
document.getElementById('selectOption').addEventListener('change', disableNLabel);

//Updating the table dropdown
listTables();

//Searching by different methods
function heroSearch(){
    //Getting sort method selected and the other inputs
    let methodSelected = document.getElementById('selectOption');
    let n = document.getElementById('nInput');
    const letters = /^[A-Za-z\s\-\/]+$/;
    const heroInput = document.getElementById('heroInput');

    //If searching by name
    if(methodSelected.value == "name"){
        //Sanitization
        if (heroInput.value.trim() === "") {
            alert("Please enter a value!");
            return;
        }
        if (!heroInput.value.match(letters)) {
            alert("Please only use letters!");
            return;
        }
        const sanitizedHeroName = heroInput.value.trim();

        //Fetching the result
        fetch(`/api/superheroes/${encodeURIComponent(sanitizedHeroName)}/result`)
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then((responseData) => {
            //Emptying the output div
            let list = document.getElementById("result");
            while (list.firstChild) {
                list.removeChild(list.firstChild);
            }

            //Iterating through the responce
            for (const hero of responseData) {
                let powersList = {};
                let id = hero[`id`];
                let name = hero[`name`];
                let gender = hero[`Gender`];
                let eyeColor = hero[`Eye color`];
                let race = hero[`Race`];
                let hairColor = hero[`Hair color`];
                let height = hero[`Height`];
                let publisher = hero[`Publisher`];
                let skinColor = hero[`Skin color`];
                let alignment = hero[`Alignment`];
                let weight = hero[`Weight`];

                //Finding all powers for that hero
                fetch(`/api/superheroes/${id}/powers`)
                .then((res) => {
                    if (!res.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return res.json();
                    
                })
                .then((resData) => {
                    //Creating the elements to append
                    powersList = resData;
                    let item = document.createElement("li");
    
                    let h1 = document.createElement("h1");
                    h1.textContent = name;
        
                    let h2 = document.createElement("h2");
                    h2.textContent = `ID: ${id}`;
        
                    let p1 = document.createElement("p");
                    p1.textContent = `Gender: ${gender}`;
        
                    let p2 = document.createElement("p");
                    p2.textContent = `Eye color: ${eyeColor}`;
        
                    let p3 = document.createElement("p");
                    p3.textContent = `Race: ${race}`;
        
                    let p4 = document.createElement("p");
                    p4.textContent = `Hair color: ${hairColor}`;
        
                    let p5 = document.createElement("p");
                    p5.textContent = `Height: ${height}`;
        
                    let p6 = document.createElement("p");
                    p6.textContent = `Publisher: ${publisher}`;
        
                    let p7 = document.createElement("p");
                    p7.textContent = `Skin color: ${skinColor}`;
                    
                    let p8 = document.createElement("p");
                    p8.textContent = `Alignment: ${alignment}`;
        
                    let p9 = document.createElement("p");
                    p9.textContent = `Weight: ${weight}`;
                    
                    let p10 = document.createElement("p");
                    let abilities = 'Powers: ';
                    for (let ability in powersList){
                        if (ability !== 'error'){
                            abilities += `${ability}, `;
                        }
                    }
                    p10.textContent = abilities.slice(0, abilities.length - 2);
        
                    item.appendChild(h1);
                    item.appendChild(h2);
                    item.appendChild(p1);
                    item.appendChild(p2);
                    item.appendChild(p3);
                    item.appendChild(p4);
                    item.appendChild(p5);
                    item.appendChild(p6);
                    item.appendChild(p7);
                    item.appendChild(p8);
                    item.appendChild(p9);
                    item.appendChild(p10);
                    item.className = "section resultList";
                    list.appendChild(item);
                })
                .catch((error) => {
                    // Handle errors
                    alert(error);
                });
            }
        })
        .catch((error) => {
            // Handle errors
            alert(error);
        });
    }
    //If searching by race
    else if(methodSelected.value == "race"){
        //Sanitization
        if (heroInput.value.trim() === "") {
            alert("Please enter a value!");
            return;
        }
        if (!heroInput.value.match(letters)) {
            alert("Please only use letters!");
            return;
        }
        if (!Number.isInteger(parseInt(n.value))) {
            alert("Please only enter integers!");
            return;
        }
        n = parseInt(n.value);
        const sanitizedRace = heroInput.value.trim();
        
        //Fetching the info
        fetch(`/api/superheroes/Race/${encodeURIComponent(sanitizedRace)}/${n}`)
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then((responseData) => {
            //Clearing the outout div
            let list = document.getElementById("result");
            while (list.firstChild) {
                list.removeChild(list.firstChild);
            }

            //Iterating throught the response
            for (const hero of responseData) {
                let powersList = {};
                let id = hero[`id`];
                let name = hero[`name`];
                let gender = hero[`Gender`];
                let eyeColor = hero[`Eye color`];
                let race = hero[`Race`];
                let hairColor = hero[`Hair color`];
                let height = hero[`Height`];
                let publisher = hero[`Publisher`];
                let skinColor = hero[`Skin color`];
                let alignment = hero[`Alignment`];
                let weight = hero[`Weight`];

                //Getting all the powers for the hero
                fetch(`/api/superheroes/${id}/powers`)
                .then((res) => {
                    if (!res.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return res.json();
                })
                .then((resData) => {
                    //Creating the elements to display
                    powersList = resData;
                    let item = document.createElement("li");
    
                    let h1 = document.createElement("h1");
                    h1.textContent = name;
        
                    let h2 = document.createElement("h2");
                    h2.textContent = `ID: ${id}`;
        
                    let p1 = document.createElement("p");
                    p1.textContent = `Gender: ${gender}`;
        
                    let p2 = document.createElement("p");
                    p2.textContent = `Eye color: ${eyeColor}`;
        
                    let p3 = document.createElement("p");
                    p3.textContent = `Race: ${race}`;
        
                    let p4 = document.createElement("p");
                    p4.textContent = `Hair color: ${hairColor}`;
        
                    let p5 = document.createElement("p");
                    p5.textContent = `Height: ${height}`;
        
                    let p6 = document.createElement("p");
                    p6.textContent = `Publisher: ${publisher}`;
        
                    let p7 = document.createElement("p");
                    p7.textContent = `Skin color: ${skinColor}`;
                    
                    let p8 = document.createElement("p");
                    p8.textContent = `Alignment: ${alignment}`;
        
                    let p9 = document.createElement("p");
                    p9.textContent = `Weight: ${weight}`;
                    
                    let p10 = document.createElement("p");
                    let abilities = 'Powers: ';
                    for (let ability in powersList){
                        if (ability !== 'error'){
                            abilities += `${ability}, `;
                        }
                    }
                    p10.textContent = abilities.slice(0, abilities.length - 2);
        
                    item.appendChild(h1);
                    item.appendChild(h2);
                    item.appendChild(p1);
                    item.appendChild(p2);
                    item.appendChild(p3);
                    item.appendChild(p4);
                    item.appendChild(p5);
                    item.appendChild(p6);
                    item.appendChild(p7);
                    item.appendChild(p8);
                    item.appendChild(p9);
                    item.appendChild(p10);
                    item.className = "section resultList";
                    list.appendChild(item);
                })
                .catch((error) => {
                    // Handle errors
                    alert(error);
                });
            }
        })
        .catch((error) => {
            // Handle errors
            alert(error);
        });
    }
    //If publisher is selected
    else if(methodSelected.value == "publisher"){
        //If no input
        if (heroInput.value == ""){
            //Getting all publishers
            fetch(`/api/superheroes/publishers`)
            .then((response) => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                // Parse the response as JSON if needed
                return response.json();
            })
            .then((responseData) => {
                // Handle the response data
                let list = document.getElementById("result");
                while (list.firstChild) {
                    list.removeChild(list.firstChild);
                }
                for (const hero of responseData) {
                    let h1 = document.createElement("h1");
                    h1.textContent = `${hero}`;
                    
                    let item = document.createElement("li");

                    item.appendChild(h1);
                    item.className = "section resultList";
                    list.appendChild(item);
                }
            })
            .catch((error) => {
                alert(error);
            });
        }
        //Sanitization
        else{
            if (!heroInput.value.match(letters)) {
                alert("Please only use letters!");
                return;
            }
            if (!Number.isInteger(parseInt(n.value))) {
                alert("Please only enter integers!");
                return;
            }
            n = parseInt(n.value);
            const sanitizedPublisher = heroInput.value.trim();

            //Fetching all publishers with this name
            fetch(`/api/superheroes/Publisher/${encodeURIComponent(sanitizedPublisher)}/${n}`)
            .then((response) => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then((responseData) => {
                // Handle the response data
                let list = document.getElementById("result");
                while (list.firstChild) {
                    list.removeChild(list.firstChild);
                }
                for (const hero of responseData) {
                    let powersList = {};
                    let id = hero[`id`];
                    let name = hero[`name`];
                    let gender = hero[`Gender`];
                    let eyeColor = hero[`Eye color`];
                    let race = hero[`Race`];
                    let hairColor = hero[`Hair color`];
                    let height = hero[`Height`];
                    let publisher = hero[`Publisher`];
                    let skinColor = hero[`Skin color`];
                    let alignment = hero[`Alignment`];
                    let weight = hero[`Weight`];
    
                    fetch(`/api/superheroes/${id}/powers`)
                    .then((res) => {
                        if (!res.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return res.json(); // Parse the response as JSON if needed
                    })
                    .then((resData) => {
                        // Handle the response data
                        powersList = resData;
                        let item = document.createElement("li");
        
                        let h1 = document.createElement("h1");
                        h1.textContent = name;
            
                        let h2 = document.createElement("h2");
                        h2.textContent = `ID: ${id}`;
            
                        let p1 = document.createElement("p");
                        p1.textContent = `Gender: ${gender}`;
            
                        let p2 = document.createElement("p");
                        p2.textContent = `Eye color: ${eyeColor}`;
            
                        let p3 = document.createElement("p");
                        p3.textContent = `Race: ${race}`;
            
                        let p4 = document.createElement("p");
                        p4.textContent = `Hair color: ${hairColor}`;
            
                        let p5 = document.createElement("p");
                        p5.textContent = `Height: ${height}`;
            
                        let p6 = document.createElement("p");
                        p6.textContent = `Publisher: ${publisher}`;
            
                        let p7 = document.createElement("p");
                        p7.textContent = `Skin color: ${skinColor}`;
                        
                        let p8 = document.createElement("p");
                        p8.textContent = `Alignment: ${alignment}`;
            
                        let p9 = document.createElement("p");
                        p9.textContent = `Weight: ${weight}`;
                        
                        let p10 = document.createElement("p");
                        let abilities = 'Powers: ';
                        for (let ability in powersList){
                            if (ability !== 'error'){
                                abilities += `${ability}, `;
                            }
                        }
                        p10.textContent = abilities.slice(0, abilities.length - 2);
            
                        item.appendChild(h1);
                        item.appendChild(h2);
                        item.appendChild(p1);
                        item.appendChild(p2);
                        item.appendChild(p3);
                        item.appendChild(p4);
                        item.appendChild(p5);
                        item.appendChild(p6);
                        item.appendChild(p7);
                        item.appendChild(p8);
                        item.appendChild(p9);
                        item.appendChild(p10);
                        item.className = "section resultList";
                        list.appendChild(item);
                    })
                    .catch((error) => {
                        // Handle errors
                        alert(error);
                    });
                }
            })
            .catch((error) => {
                // Handle errors
                alert(error);
            });
        }
    }
    //If power is selected
    else if(methodSelected.value == "power"){
        //Sanitization
        if (heroInput.value.trim() === "") {
            return;
        }
        if (!heroInput.value.match(letters)) {
            alert("Please only use letters!");
            return;
        }
        const sanitizedPower = heroInput.value.trim();

        //Fetching for powerName
        fetch(`/api/superheroes/`)
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json(); // Parse the response as JSON if needed
        })
        .then((responseData) => {
            // Handle the response data
            let list = document.getElementById("result");
            while (list.firstChild) {
                list.removeChild(list.firstChild);
            }
            for (const hero of responseData) {
                let powersList = {};
                let id = hero[`id`];
                let name = hero[`name`];
                let gender = hero[`Gender`];
                let eyeColor = hero[`Eye color`];
                let race = hero[`Race`];
                let hairColor = hero[`Hair color`];
                let height = hero[`Height`];
                let publisher = hero[`Publisher`];
                let skinColor = hero[`Skin color`];
                let alignment = hero[`Alignment`];
                let weight = hero[`Weight`];

                fetch(`/api/superheroes/${id}/powers`)
                .then((res) => {
                    if (!res.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return res.json(); // Parse the response as JSON if needed
                })
                .then((resData) => {
                    // Handle the response data
                    powersList = resData;
                    let shouldAdd = false;

                    let item = document.createElement("li");
    
                    let h1 = document.createElement("h1");
                    h1.textContent = name;
        
                    let h2 = document.createElement("h2");
                    h2.textContent = `ID: ${id}`;
        
                    let p1 = document.createElement("p");
                    p1.textContent = `Gender: ${gender}`;
        
                    let p2 = document.createElement("p");
                    p2.textContent = `Eye color: ${eyeColor}`;
        
                    let p3 = document.createElement("p");
                    p3.textContent = `Race: ${race}`;
        
                    let p4 = document.createElement("p");
                    p4.textContent = `Hair color: ${hairColor}`;
        
                    let p5 = document.createElement("p");
                    p5.textContent = `Height: ${height}`;
        
                    let p6 = document.createElement("p");
                    p6.textContent = `Publisher: ${publisher}`;
        
                    let p7 = document.createElement("p");
                    p7.textContent = `Skin color: ${skinColor}`;
                    
                    let p8 = document.createElement("p");
                    p8.textContent = `Alignment: ${alignment}`;
        
                    let p9 = document.createElement("p");
                    p9.textContent = `Weight: ${weight}`;
                    
                    let p10 = document.createElement("p");
                    let abilities = 'Powers: ';
                    for (let ability in powersList){
                        if (ability.toLowerCase().includes(heroInput.value.toLowerCase())){
                            shouldAdd = true;
                        }
                        if (ability !== 'error'){
                            abilities += `${ability}, `;
                        }
                    }
                    
                    if(shouldAdd){
                        p10.textContent = abilities.slice(0, abilities.length - 2);
            
                        item.appendChild(h1);
                        item.appendChild(h2);
                        item.appendChild(p1);
                        item.appendChild(p2);
                        item.appendChild(p3);
                        item.appendChild(p4);
                        item.appendChild(p5);
                        item.appendChild(p6);
                        item.appendChild(p7);
                        item.appendChild(p8);
                        item.appendChild(p9);
                        item.appendChild(p10);
                        item.className = "section resultList";
                        list.appendChild(item);
                    }
                })
                .catch((error) => {
                    // Handle errors
                    alert(error);
                });
            }
        })
        .catch((error) => {
            // Handle errors
            alert(error);
        });
    }
    //If ID is selected
    else if(methodSelected.value == "id"){
        if (heroInput.value.trim() === "") {
            alert("Please enter a value!");
            return;
        }
        if (!Number.isInteger(parseInt(heroInput.value))) {
            alert("Please only enter integers!");
            return;
        }
        const sanitizedId = heroInput.value.trim();
        fetch(`/api/superheroes/${encodeURIComponent(sanitizedId)}`)
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json(); // Parse the response as JSON
        })
        .then((hero) => {
            // Handle the response data
            let list = document.getElementById("result");
            while (list.firstChild) {
                list.removeChild(list.firstChild);
            }
            let powersList = {};
            let id = hero[`id`];
            let name = hero[`name`];
            let gender = hero[`Gender`];
            let eyeColor = hero[`Eye color`];
            let race = hero[`Race`];
            let hairColor = hero[`Hair color`];
            let height = hero[`Height`];
            let publisher = hero[`Publisher`];
            let skinColor = hero[`Skin color`];
            let alignment = hero[`Alignment`];
            let weight = hero[`Weight`];

            fetch(`/api/superheroes/${id}/powers`)
            .then((res) => {
                if (!res.ok) {
                    throw new Error('Network response was not ok');
                }
                return res.json(); // Parse the response as JSON if needed
                
            })
            .then((resData) => {
                // Handle the response data
                powersList = resData;
                let item = document.createElement("li");

                let h1 = document.createElement("h1");
                h1.textContent = name;
    
                let h2 = document.createElement("h2");
                h2.textContent = `ID: ${id}`;
    
                let p1 = document.createElement("p");
                p1.textContent = `Gender: ${gender}`;
    
                let p2 = document.createElement("p");
                p2.textContent = `Eye color: ${eyeColor}`;
    
                let p3 = document.createElement("p");
                p3.textContent = `Race: ${race}`;
    
                let p4 = document.createElement("p");
                p4.textContent = `Hair color: ${hairColor}`;
    
                let p5 = document.createElement("p");
                p5.textContent = `Height: ${height}`;
    
                let p6 = document.createElement("p");
                p6.textContent = `Publisher: ${publisher}`;
    
                let p7 = document.createElement("p");
                p7.textContent = `Skin color: ${skinColor}`;
                
                let p8 = document.createElement("p");
                p8.textContent = `Alignment: ${alignment}`;
    
                let p9 = document.createElement("p");
                p9.textContent = `Weight: ${weight}`;
                
                let p10 = document.createElement("p");
                let abilities = 'Powers: ';
                for (let ability in powersList){
                    if (ability !== 'error'){
                        abilities += `${ability}, `;
                    }
                }
                p10.textContent = abilities.slice(0, abilities.length - 2);
    
                item.appendChild(h1);
                item.appendChild(h2);
                item.appendChild(p1);
                item.appendChild(p2);
                item.appendChild(p3);
                item.appendChild(p4);
                item.appendChild(p5);
                item.appendChild(p6);
                item.appendChild(p7);
                item.appendChild(p8);
                item.appendChild(p9);
                item.appendChild(p10);
                item.className = "section resultList";
                list.appendChild(item);
            })
            .catch((error) => {
                // Handle errors
                alert(error);
            });
        })
        .catch((error) => {
            // Handle errors
            alert(error);
        });
    }
}

//Creating a list with a given name
function createList() {
    let listNameInput = document.getElementById('listNameInput');

    if (listNameInput.value.trim() === "") {
        alert("Please enter a value!");
        return;
    }
    
    const listName = encodeURIComponent(listNameInput.value.trim());

    fetch(`/api/superheroes/${listName}`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'}
    })
    .then((response) => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.text(); // Parse the response as JSON
    })
    .then((responseData) => {
        // Handle the response data
        alert("List is created!");
        listTables();
    })
    .catch((error) => {
        // Handle errors
        alert(error);
    });
}

//All info for a list 
function listInfo(){
    let listOption = document.getElementById('listOption');

    fetch(`/api/superheroes/${listOption.value}/allInfo`)
    .then((response) => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json(); // Parse the response as JSON
    })
    .then((responseData) => {
        // Handle the response data
        let list = document.getElementById("result");
        while (list.firstChild) {
            list.removeChild(list.firstChild);
        }
        for (const hero of responseData) {
            let id = hero[`id`];
            let name = hero[`name`];
            let gender = hero[`Gender`];
            let eyeColor = hero[`Eye color`];
            let race = hero[`Race`];
            let hairColor = hero[`Hair color`];
            let height = hero[`Height`];
            let publisher = hero[`Publisher`];
            let skinColor = hero[`Skin color`];
            let alignment = hero[`Alignment`];
            let weight = hero[`Weight`];
            let power = 'Power: ';

            for (let index in hero){
                if (hero[index] == "True"){
                    power += `${index}, `;
                }
            }
            power = power.slice(0, power.length - 2);

            let item = document.createElement("li");
        
            let h1 = document.createElement("h1");
            h1.textContent = name;

            let h2 = document.createElement("h2");
            h2.textContent = `ID: ${id}`;

            let p1 = document.createElement("p");
            p1.textContent = `Gender: ${gender}`;

            let p2 = document.createElement("p");
            p2.textContent = `Eye color: ${eyeColor}`;

            let p3 = document.createElement("p");
            p3.textContent = `Race: ${race}`;

            let p4 = document.createElement("p");
            p4.textContent = `Hair color: ${hairColor}`;

            let p5 = document.createElement("p");
            p5.textContent = `Height: ${height}`;

            let p6 = document.createElement("p");
            p6.textContent = `Publisher: ${publisher}`;

            let p7 = document.createElement("p");
            p7.textContent = `Skin color: ${skinColor}`;
            
            let p8 = document.createElement("p");
            p8.textContent = `Alignment: ${alignment}`;

            let p9 = document.createElement("p");
            p9.textContent = `Weight: ${weight}`;
            
            let p10 = document.createElement("p");
            p10.textContent = power;

            item.appendChild(h1);
            item.appendChild(h2);
            item.appendChild(p1);
            item.appendChild(p2);
            item.appendChild(p3);
            item.appendChild(p4);
            item.appendChild(p5);
            item.appendChild(p6);
            item.appendChild(p7);
            item.appendChild(p8);
            item.appendChild(p9);
            item.appendChild(p10);
            item.className = "section resultList";
            list.appendChild(item);
        }
    })
    .catch((error) => {
        // Handle errors
        alert(error);
    });
}

//Deleting a list
function deleteList(){
    let listOption = document.getElementById('listOption');
    fetch(`/api/superheroes/${listOption.value}/deleteList`, {
        method: 'DELETE',
        headers: {'Content-Type' : 'application/json'}
    })
    .then((response) => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json(); // Parse the response as JSON
    })
    .then((responseData) => {
        // Handle the response data
        listTables();
        alert("List is deleted!");
    })
    .catch((error) => {
        // Handle errors
        alert(error);
    });
}

//Add ID's to a list
function addIDList() {
    let listSelected = document.getElementById('listOption');
    let idInput = document.getElementById('idInput');

    // Validate the input to allow only numbers and commas
    var validInput = /^[0-9,]+$/;
    if (!validInput.test(idInput.value)) {
        alert("Please only use valid numbers and commas!");
        return;
    }

    // Split the input by commas and validate each individual ID
    const idArray = idInput.value.split(',').map(id => id.trim());
    for (const id of idArray) {
        if (!/^\d+$/.test(id)) {
            alert("Please enter valid numeric IDs separated by commas.");
            return;
        }
    }

    // Sanitize and convert to an array for the request body
    const sanitizedIDs = idArray.map(id => parseInt(id));

    fetch(`/api/superheroes/${listSelected.value}`, {
        method: 'PUT',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(sanitizedIDs)
    })
    .then((response) => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json(); // Parse the response as JSON if needed
    })
    .then((responseData) => {
        // Handle the response data
        alert("ID's were added!");
    })
    .catch((error) => {
        // Handle errors
        alert(error);
    });
}

//Only show the ID's
function idList(){
    let listOption = document.getElementById('listOption');
    fetch(`/api/superheroes/${listOption.value}/id`)
    .then((response) => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json(); // Parse the response as JSON
    })
    .then((responseData) => {
        // Handle the response data
        let list = document.getElementById("result");

        while (list.firstChild) {
            list.removeChild(list.firstChild);
        }

        for (let index of responseData) {
            let item = document.createElement("li");
        
            let h1 = document.createElement("h1");
            h1.textContent = `ID: ${index['id']}`;

            item.appendChild(h1);
            item.className = "section resultList";
            list.appendChild(item);
        }
    })
    .catch((error) => {
        // Handle errors
        alert(error);
    });
}

//Sort by name
function nameSortMethod(){
    let list = document.querySelectorAll("result");
    const listItems = document.querySelectorAll("li");
    let nameArray = [];

    for (let i = 0; i < listItems.length; i++) {
        const item = listItems[i];
        const firstChild = item.firstElementChild;
        nameArray.push(firstChild.textContent);
    }
    nameArray.sort();
    
    while (list.firstChild) {
        list.removeChild(list.firstChild);
    }

    for (let i = 0; i < nameArray.length; i++){
        fetch(`/api/superheroes/${nameArray[i]}/result`)
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json(); // Parse the response as JSON if needed
        })
        .then((responseData) => {
            // Handle the response data
            let list = document.getElementById("result");
            while (list.firstChild) {
                list.removeChild(list.firstChild);
            }
            for (const hero of responseData) {
                let powersList = {};
                let id = hero[`id`];
                let name = hero[`name`];
                let gender = hero[`Gender`];
                let eyeColor = hero[`Eye color`];
                let race = hero[`Race`];
                let hairColor = hero[`Hair color`];
                let height = hero[`Height`];
                let publisher = hero[`Publisher`];
                let skinColor = hero[`Skin color`];
                let alignment = hero[`Alignment`];
                let weight = hero[`Weight`];

                fetch(`/api/superheroes/${id}/powers`)
                .then((res) => {
                    if (!res.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return res.json(); // Parse the response as JSON if needed
                    
                })
                .then((resData) => {
                    // Handle the response data
                    powersList = resData;
                    let item = document.createElement("li");
    
                    let h1 = document.createElement("h1");
                    h1.textContent = name;
        
                    let h2 = document.createElement("h2");
                    h2.textContent = `ID: ${id}`;
        
                    let p1 = document.createElement("p");
                    p1.textContent = `Gender: ${gender}`;
        
                    let p2 = document.createElement("p");
                    p2.textContent = `Eye color: ${eyeColor}`;
        
                    let p3 = document.createElement("p");
                    p3.textContent = `Race: ${race}`;
        
                    let p4 = document.createElement("p");
                    p4.textContent = `Hair color: ${hairColor}`;
        
                    let p5 = document.createElement("p");
                    p5.textContent = `Height: ${height}`;
        
                    let p6 = document.createElement("p");
                    p6.textContent = `Publisher: ${publisher}`;
        
                    let p7 = document.createElement("p");
                    p7.textContent = `Skin color: ${skinColor}`;
                    
                    let p8 = document.createElement("p");
                    p8.textContent = `Alignment: ${alignment}`;
        
                    let p9 = document.createElement("p");
                    p9.textContent = `Weight: ${weight}`;
                    
                    let p10 = document.createElement("p");
                    let abilities = 'Powers: ';
                    for (let ability in powersList){
                        if (ability !== 'error'){
                            abilities += `${ability}, `;
                        }
                    }
                    p10.textContent = abilities.slice(0, abilities.length - 2);
        
                    item.appendChild(h1);
                    item.appendChild(h2);
                    item.appendChild(p1);
                    item.appendChild(p2);
                    item.appendChild(p3);
                    item.appendChild(p4);
                    item.appendChild(p5);
                    item.appendChild(p6);
                    item.appendChild(p7);
                    item.appendChild(p8);
                    item.appendChild(p9);
                    item.appendChild(p10);
                    item.className = "section resultList";
                    list.appendChild(item);
                })
                .catch((error) => {
                    // Handle errors
                    alert(error);
                });
            }
        })
        .catch((error) => {
            // Handle errors
            alert(error);
        });
    }
}

//Sort by race
function raceSortMethod(){
    let list = document.querySelectorAll("result");
    const listItems = document.querySelectorAll("li");
    let nameArray = [];

    for (let i = 0; i < listItems.length; i++) {
        const item = listItems[i];
        const firstChild = item.children[4];
        nameArray.push(firstChild.textContent + ',' + item.firstElementChild.textContent);
    }
    nameArray.sort();
    
    while (list.firstChild) {
        list.removeChild(list.firstChild);
    }

    for (let i = 0; i < nameArray.length; i++){
        fetch(`/api/superheroes/${nameArray[i].split(',')[1]}/result`)
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json(); // Parse the response as JSON if needed
        })
        .then((responseData) => {
            // Handle the response data
            let list = document.getElementById("result");
            while (list.firstChild) {
                list.removeChild(list.firstChild);
            }
            for (const hero of responseData) {
                let powersList = {};
                let id = hero[`id`];
                let name = hero[`name`];
                let gender = hero[`Gender`];
                let eyeColor = hero[`Eye color`];
                let race = hero[`Race`];
                let hairColor = hero[`Hair color`];
                let height = hero[`Height`];
                let publisher = hero[`Publisher`];
                let skinColor = hero[`Skin color`];
                let alignment = hero[`Alignment`];
                let weight = hero[`Weight`];

                fetch(`/api/superheroes/${id}/powers`)
                .then((res) => {
                    if (!res.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return res.json(); // Parse the response as JSON if needed
                    
                })
                .then((resData) => {
                    // Handle the response data
                    powersList = resData;
                    let item = document.createElement("li");
    
                    let h1 = document.createElement("h1");
                    h1.textContent = name;
        
                    let h2 = document.createElement("h2");
                    h2.textContent = `ID: ${id}`;
        
                    let p1 = document.createElement("p");
                    p1.textContent = `Gender: ${gender}`;
        
                    let p2 = document.createElement("p");
                    p2.textContent = `Eye color: ${eyeColor}`;
        
                    let p3 = document.createElement("p");
                    p3.textContent = `Race: ${race}`;
        
                    let p4 = document.createElement("p");
                    p4.textContent = `Hair color: ${hairColor}`;
        
                    let p5 = document.createElement("p");
                    p5.textContent = `Height: ${height}`;
        
                    let p6 = document.createElement("p");
                    p6.textContent = `Publisher: ${publisher}`;
        
                    let p7 = document.createElement("p");
                    p7.textContent = `Skin color: ${skinColor}`;
                    
                    let p8 = document.createElement("p");
                    p8.textContent = `Alignment: ${alignment}`;
        
                    let p9 = document.createElement("p");
                    p9.textContent = `Weight: ${weight}`;
                    
                    let p10 = document.createElement("p");
                    let abilities = 'Powers: ';
                    for (let ability in powersList){
                        if (ability !== 'error'){
                            abilities += `${ability}, `;
                        }
                    }
                    p10.textContent = abilities.slice(0, abilities.length - 2);
        
                    item.appendChild(h1);
                    item.appendChild(h2);
                    item.appendChild(p1);
                    item.appendChild(p2);
                    item.appendChild(p3);
                    item.appendChild(p4);
                    item.appendChild(p5);
                    item.appendChild(p6);
                    item.appendChild(p7);
                    item.appendChild(p8);
                    item.appendChild(p9);
                    item.appendChild(p10);
                    item.className = "section resultList";
                    list.appendChild(item);
                })
                .catch((error) => {
                    // Handle errors
                    alert(error);
                });
            }
        })
        .catch((error) => {
            // Handle errors
            alert(error);
        });
    }
}

//Sort by publisher
function publisherSortMethod(){
    let list = document.querySelectorAll("result");
    const listItems = document.querySelectorAll("li");
    let nameArray = [];

    for (let i = 0; i < listItems.length; i++) {
        const item = listItems[i];
        const firstChild = item.children[7];
        nameArray.push(firstChild.textContent + ',' + item.firstElementChild.textContent);
    }
    nameArray.sort();
    
    while (list.firstChild) {
        list.removeChild(list.firstChild);
    }

    for (let i = 0; i < nameArray.length; i++){
        fetch(`/api/superheroes/${nameArray[i].split(',')[1]}/result`)
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json(); // Parse the response as JSON if needed
        })
        .then((responseData) => {
            // Handle the response data
            let list = document.getElementById("result");
            while (list.firstChild) {
                list.removeChild(list.firstChild);
            }
            for (const hero of responseData) {
                let powersList = {};
                let id = hero[`id`];
                let name = hero[`name`];
                let gender = hero[`Gender`];
                let eyeColor = hero[`Eye color`];
                let race = hero[`Race`];
                let hairColor = hero[`Hair color`];
                let height = hero[`Height`];
                let publisher = hero[`Publisher`];
                let skinColor = hero[`Skin color`];
                let alignment = hero[`Alignment`];
                let weight = hero[`Weight`];

                fetch(`/api/superheroes/${id}/powers`)
                .then((res) => {
                    if (!res.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return res.json(); // Parse the response as JSON if needed
                    
                })
                .then((resData) => {
                    // Handle the response data
                    powersList = resData;
                    let item = document.createElement("li");
    
                    let h1 = document.createElement("h1");
                    h1.textContent = name;
        
                    let h2 = document.createElement("h2");
                    h2.textContent = `ID: ${id}`;
        
                    let p1 = document.createElement("p");
                    p1.textContent = `Gender: ${gender}`;
        
                    let p2 = document.createElement("p");
                    p2.textContent = `Eye color: ${eyeColor}`;
        
                    let p3 = document.createElement("p");
                    p3.textContent = `Race: ${race}`;
        
                    let p4 = document.createElement("p");
                    p4.textContent = `Hair color: ${hairColor}`;
        
                    let p5 = document.createElement("p");
                    p5.textContent = `Height: ${height}`;
        
                    let p6 = document.createElement("p");
                    p6.textContent = `Publisher: ${publisher}`;
        
                    let p7 = document.createElement("p");
                    p7.textContent = `Skin color: ${skinColor}`;
                    
                    let p8 = document.createElement("p");
                    p8.textContent = `Alignment: ${alignment}`;
        
                    let p9 = document.createElement("p");
                    p9.textContent = `Weight: ${weight}`;
                    
                    let p10 = document.createElement("p");
                    let abilities = 'Powers: ';
                    for (let ability in powersList){
                        if (ability !== 'error'){
                            abilities += `${ability}, `;
                        }
                    }
                    p10.textContent = abilities.slice(0, abilities.length - 2);
        
                    item.appendChild(h1);
                    item.appendChild(h2);
                    item.appendChild(p1);
                    item.appendChild(p2);
                    item.appendChild(p3);
                    item.appendChild(p4);
                    item.appendChild(p5);
                    item.appendChild(p6);
                    item.appendChild(p7);
                    item.appendChild(p8);
                    item.appendChild(p9);
                    item.appendChild(p10);
                    item.className = "section resultList";
                    list.appendChild(item);
                })
                .catch((error) => {
                    // Handle errors
                    alert(error);
                });
            }
        })
        .catch((error) => {
            // Handle errors
            alert(error);
        });
    }
}

//Sort by power
function powerSortMethod(){
    let list = document.querySelectorAll("result");
    const listItems = document.querySelectorAll("li");
    let nameArray = [];

    for (let i = 0; i < listItems.length; i++) {
        const item = listItems[i];
        const firstChild = item.children[11];
        nameArray.push(firstChild.textContent + ',' + item.firstElementChild.textContent);
    }
    nameArray.sort();
    
    while (list.firstChild) {
        list.removeChild(list.firstChild);
    }

    for (let i = 0; i < nameArray.length; i++){
        let searchName = nameArray[i].split(',').length;
        fetch(`/api/superheroes/${nameArray[i].split(',')[searchName - 1]}/result`)
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json(); // Parse the response as JSON if needed
        })
        .then((responseData) => {
            // Handle the response data
            let list = document.getElementById("result");
            while (list.firstChild) {
                list.removeChild(list.firstChild);
            }
            for (const hero of responseData) {
                let powersList = {};
                let id = hero[`id`];
                let name = hero[`name`];
                let gender = hero[`Gender`];
                let eyeColor = hero[`Eye color`];
                let race = hero[`Race`];
                let hairColor = hero[`Hair color`];
                let height = hero[`Height`];
                let publisher = hero[`Publisher`];
                let skinColor = hero[`Skin color`];
                let alignment = hero[`Alignment`];
                let weight = hero[`Weight`];

                fetch(`/api/superheroes/${id}/powers`)
                .then((res) => {
                    if (!res.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return res.json(); // Parse the response as JSON if needed
                    
                })
                .then((resData) => {
                    // Handle the response data
                    powersList = resData;
                    let item = document.createElement("li");
    
                    let h1 = document.createElement("h1");
                    h1.textContent = name;
        
                    let h2 = document.createElement("h2");
                    h2.textContent = `ID: ${id}`;
        
                    let p1 = document.createElement("p");
                    p1.textContent = `Gender: ${gender}`;
        
                    let p2 = document.createElement("p");
                    p2.textContent = `Eye color: ${eyeColor}`;
        
                    let p3 = document.createElement("p");
                    p3.textContent = `Race: ${race}`;
        
                    let p4 = document.createElement("p");
                    p4.textContent = `Hair color: ${hairColor}`;
        
                    let p5 = document.createElement("p");
                    p5.textContent = `Height: ${height}`;
        
                    let p6 = document.createElement("p");
                    p6.textContent = `Publisher: ${publisher}`;
        
                    let p7 = document.createElement("p");
                    p7.textContent = `Skin color: ${skinColor}`;
                    
                    let p8 = document.createElement("p");
                    p8.textContent = `Alignment: ${alignment}`;
        
                    let p9 = document.createElement("p");
                    p9.textContent = `Weight: ${weight}`;
                    
                    let p10 = document.createElement("p");
                    let abilities = 'Powers: ';
                    for (let ability in powersList){
                        if (ability !== 'error'){
                            abilities += `${ability}, `;
                        }
                    }
                    p10.textContent = abilities.slice(0, abilities.length - 2);
        
                    item.appendChild(h1);
                    item.appendChild(h2);
                    item.appendChild(p1);
                    item.appendChild(p2);
                    item.appendChild(p3);
                    item.appendChild(p4);
                    item.appendChild(p5);
                    item.appendChild(p6);
                    item.appendChild(p7);
                    item.appendChild(p8);
                    item.appendChild(p9);
                    item.appendChild(p10);
                    item.className = "section resultList";
                    list.appendChild(item);
                })
                .catch((error) => {
                    // Handle errors
                    alert(error);
                });
            }
        })
        .catch((error) => {
            // Handle errors
            alert(error);
        });
    }
}

//Disabling the number input
function disableNLabel(){
    const n = document.getElementById("nInput");
    const option = document.getElementById('selectOption');

    if (option.value == "name" || option.value == "power" || option.value == "id"){
        n.value = '';
        n.disabled = true;
    }
    else{
        n.disabled = false;
    }
}

//Adding all tables to the dropdown
function listTables(){
    fetch(`/api/superheroes/tableNames`)
    .then((response) => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json(); // Parse the response as JSON
    })
    .then((responseData) => {
        // Handle the response data
        let list = document.getElementById("result");
        let dropDown = document.getElementById("listOption");

        let i; 
        let length = dropDown.options.length - 1;
        for(i = length; i >= 0; i--) {
            dropDown.remove(i);
        }

        while (list.firstChild) {
            list.removeChild(list.firstChild);
        }

        for (let index of responseData) {
            if (!(index == "superpowers" || index == "superheroinfos")){
                let option = document.createElement("option");
                option.textContent = index;
                option.value = index;
                dropDown.appendChild(option);
            }
        }
    })
    .catch((error) => {
        // Handle errors
        alert(error);
    });
}